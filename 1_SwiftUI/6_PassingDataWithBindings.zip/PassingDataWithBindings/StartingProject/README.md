# Passing Data with Bindings

## Starting Project

Use this project to code along with [Passing Data with Bindings](https://developer.apple.com/tutorials/app-dev-training/passing-data-with-bindings).

## Change Log

* Added an `update(from:)` function in `DailyScrum`.


