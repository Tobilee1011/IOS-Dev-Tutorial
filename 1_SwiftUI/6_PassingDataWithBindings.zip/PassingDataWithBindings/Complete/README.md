# Passing Data with Bindings

## Completed Project

Explore the completed project for [Passing Data with Bindings](https://developer.apple.com/tutorials/app-dev-training/passing-data-with-bindings).