//
//  SwiftUIView.swift
//  Landmarks
//
//  Created by tobilee1011 on 2022/07/22.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Image("MetaMask")
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
