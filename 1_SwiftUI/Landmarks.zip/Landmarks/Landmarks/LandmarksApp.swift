//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by tobilee1011 on 2022/07/22.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
