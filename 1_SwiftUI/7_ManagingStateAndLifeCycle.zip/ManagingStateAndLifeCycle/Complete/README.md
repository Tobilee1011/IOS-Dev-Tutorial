# Managing State and Life Cycle

## Completed Project

Explore the completed project for [Managing State and Life Cycle](https://developer.apple.com/tutorials/app-dev-training/managing-state-and-life-cycle).