# Creating a Card View

## Starting Project

Use this project to code along with [Creating a Card View](https://developer.apple.com/tutorials/app-dev-training/creating-a-card-view).

## Change Log

* Added an app icon and color literals in the asset catalog.
