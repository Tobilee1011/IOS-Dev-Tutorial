# Drawing the Timer View

## Completed Project

Explore the completed project for [Drawing the Timer View](https://developer.apple.com/tutorials/app-dev-training/drawing-the-timer-view).