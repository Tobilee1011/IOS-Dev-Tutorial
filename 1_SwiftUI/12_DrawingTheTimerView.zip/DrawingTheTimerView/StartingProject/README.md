# Drawing the Timer View

## Starting Project

Use this project to code along with [Drawing the Timer View](https://developer.apple.com/tutorials/app-dev-training/drawing-the-timer-view).