# Transcribing Speech to Text

## Completed Project

Explore the completed project for [Transcribing Speech to Text](https://developer.apple.com/tutorials/app-dev-training/transcribing-speech-to-text).