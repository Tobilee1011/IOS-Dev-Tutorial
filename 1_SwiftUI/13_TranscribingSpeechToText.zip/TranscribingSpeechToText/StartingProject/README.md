# Transcribing Speech to Text

## Starting Project

Use this project to code along with [Transcribing Speech to Text](https://developer.apple.com/tutorials/app-dev-training/transcribing-speech-to-text).

## Change Log

* Added a `SpeechRecognizer` class.

