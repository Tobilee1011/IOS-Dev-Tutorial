# Displaying Cell Info

## Starting Project

Use this project to code along with [Displaying Cell Info](https://developer.apple.com/tutorials/app-dev-training/displaying-cell-info).