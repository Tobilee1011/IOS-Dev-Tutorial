# Displaying Cell Info

## Completed Project

Explore the completed project for [Displaying Cell Info](https://developer.apple.com/tutorials/app-dev-training/displaying-cell-info).