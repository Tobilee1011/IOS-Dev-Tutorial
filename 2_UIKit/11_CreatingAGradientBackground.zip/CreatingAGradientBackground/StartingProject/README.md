# Creating a Gradient Background

## Starting Project

Use this project to code along with [Creating a Gradient Background](https://developer.apple.com/tutorials/app-dev-training/creating-a-gradient-background).