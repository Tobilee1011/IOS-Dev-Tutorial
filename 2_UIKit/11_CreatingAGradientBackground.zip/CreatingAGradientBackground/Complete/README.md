# Creating a Gradient Background

## Completed Project

Explore the completed project for [Creating a Gradient Background](https://developer.apple.com/tutorials/app-dev-training/creating-a-gradient-background).