/*
See LICENSE folder for this sample’s licensing information.
*/

import UIKit

class ReminderDoneButton: UIButton {
    var id: Reminder.ID?
}

