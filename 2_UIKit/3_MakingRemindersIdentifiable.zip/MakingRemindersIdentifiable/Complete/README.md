# Making Reminders Identifiable

## Completed Project

Explore the completed project for [Making Reminders Identifiable](https://developer.apple.com/tutorials/app-dev-training/making-reminders-identifiable).