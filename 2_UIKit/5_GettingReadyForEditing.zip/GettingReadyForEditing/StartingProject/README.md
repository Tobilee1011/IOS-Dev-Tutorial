# Getting Ready for Editing

## Starting Project

Use this project to code along with [Getting Ready for Editing](https://developer.apple.com/tutorials/app-dev-training/getting-ready-for-editing).