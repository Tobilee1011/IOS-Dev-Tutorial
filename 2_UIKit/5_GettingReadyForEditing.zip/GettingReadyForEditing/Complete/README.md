# Getting Ready for Editing

## Completed Project

Explore the completed project for [Getting Ready for Editing](https://developer.apple.com/tutorials/app-dev-training/getting-ready-for-editing).