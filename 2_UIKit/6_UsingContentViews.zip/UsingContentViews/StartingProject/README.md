# Using Content Views

## Starting Project

Use this project to code along with [Using Content Views](https://developer.apple.com/tutorials/app-dev-training/using-content-views).