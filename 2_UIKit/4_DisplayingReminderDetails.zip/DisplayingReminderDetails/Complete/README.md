# Displaying Reminder Details

## Completed Project

Explore the completed project for [Displaying Reminder Details](https://developer.apple.com/tutorials/app-dev-training/displaying-reminder-details).