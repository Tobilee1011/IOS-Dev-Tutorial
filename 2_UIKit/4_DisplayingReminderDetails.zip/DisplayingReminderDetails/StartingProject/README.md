# Displaying Reminder Details

## Starting Project

Use this project to code along with [Displaying Reminder Details](https://developer.apple.com/tutorials/app-dev-training/displaying-reminder-details).