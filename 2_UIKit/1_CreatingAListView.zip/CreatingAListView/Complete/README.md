# Creating a List View

## Completed Project

Explore the completed project for [Creating a List View](https://developer.apple.com/tutorials/app-dev-training/creating-a-list-view).